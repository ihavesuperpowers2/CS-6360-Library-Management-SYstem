fileObj = open('borrowers.csv', 'r', encoding="utf-8")
ftext = open("parse_result_borrowers.txt", "a", encoding="utf-8")

text_file = list(fileObj)

for line in text_file[1:15]:
    print('-' * 80)
    line = line.strip()
    column_list = line.split(',')

    card_id = column_list[0]
    ssn = column_list[1]

    bname = column_list[2] + ' ' + column_list[3]
    address = column_list[5] + ' ' + column_list[6] + ' ' + column_list[7]
    phone = column_list[8]
    # s = "INSERT INTO BORROWERS(Card_id, SSN, Bname, Address, Phone) SELECT $$"

    ftext.write(bname)


fileObj.close()
ftext.close()
