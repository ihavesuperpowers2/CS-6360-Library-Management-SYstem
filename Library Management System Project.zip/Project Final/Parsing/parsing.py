#!/usr/bin/python3

fileObj = open('books.csv', 'r', encoding="utf-8")
ftext1 = open("parse_result.txt", "a", encoding="utf-8")
ftext2 = open("parse_result_2.txt", "a", encoding="utf-8")
ftext3 = open("parse_result_3.txt", "a", encoding="utf-8")
text_file = list(fileObj)
author_id = 0
author_list = {}
for line in text_file[1:-1]:
    print('-' * 80)
    line = line.strip()
    column_list = line.split('\t')
    # print(column_list)
    isbn13 = column_list[1]
    title = column_list[2]
    authors = column_list[3]
    s = "INSERT INTO Books(Isbn, Title) SELECT $$"+isbn13+"$$,$$"+title + \
        "$$ WHERE NOT EXISTS ( SELECT isbn FROM books WHERE isbn =$$" + \
        isbn13+"$$);\n"
    ftext1.write(s)
    authors = authors.split(',')
    for author in authors:

        if (author in author_list):
            # Deal with duplicate author
            print(author + " already exists")

            s = "INSERT INTO BOOK_AUTHORS(AUTHOR_ID ,ISBN) SELECT $$"+str(author_list[author])+"$$,$$"+isbn13 + \
                "$$ WHERE NOT EXISTS ( SELECT author_id, isbn FROM Book_Authors WHERE Author_id =$$" + \
                str(author_list[author])+"$$ and isbn = $$" + isbn13 + "$$);\n"

            ftext3.write(s)

            # Lookup existing author_id and populate author_id variable
        else:
            # Add author to list
            author_id += 1
            author_list[author] = author_id
            # Be sure to look up existing author if applicable

            s = "INSERT INTO Authors(Author_Id, Name) SELECT $$" + str(author_id) + \
                "$$,$$" + author + \
                "$$ WHERE NOT EXISTS (SELECT Author_id FROM Authors where Author_id = $$" + \
                str(author_id)+"$$);\n"
            ftext2.write(s)

            s = "INSERT INTO BOOK_AUTHORS(AUTHOR_ID ,ISBN) SELECT $$"+str(author_id)+"$$,$$"+isbn13 + \
                "$$ WHERE NOT EXISTS ( SELECT author_id, isbn FROM Book_Authors WHERE Author_id =$$" + \
                str(author_id)+"$$ and isbn = $$" + isbn13 + "$$);\n"

            ftext3.write(s)


print('=' * 80)
print(author_list)

fileObj.close()
ftext1.close()
ftext2.close()
ftext3.close()
