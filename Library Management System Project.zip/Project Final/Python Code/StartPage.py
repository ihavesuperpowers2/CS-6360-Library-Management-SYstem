import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk
import Page2
import Page1
import StartPage


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class StartPage(tk.Frame):

    def refreshTable(self, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        '''
        for array in read():
            my_tree.insert(parent='', index='end', iid=array,
                           text="", values=(array), tag="orow")
        '''

        my_tree.tag_configure(
            'orow', background='#EEEEEE', font=('Arial', 12))
        my_tree.grid(row=8, column=1, columnspan=6,
                     rowspan=11, padx=0, pady=20)

    def showsearchbar(self):
        searchLabel = Label(self, text="Search", font=('Arial', 15))
        searchLabel.grid(row=3, column=0, columnspan=1, padx=10, pady=0)
        searchEntry = Entry(self, width=40, bd=5,
                            font=('Arial', 15))

        searchEntry.grid(row=3, column=1, columnspan=4, padx=5, pady=2)
        return searchEntry

        # checkOutBtn = Button(self, text="Check Out", padx=65, pady=7,
        # width=5, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: self.show_page1(searchEntry))

        # checkOutBtn.grid(row=31, column=1, columnspan=2, rowspan=1)
    def search(self, searchEntry, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        searchstring = str(searchEntry.get())
        searchlist = searchstring.split(' ')
        conn = connection()
        cursor = conn.cursor()
        result = []
        for i in range(len(searchlist) - 1, -1, -1):
            book_string = ' '.join(map(str, searchlist[0:i+1]))
            print(book_string)
            cursor = conn.cursor()
            cursor.execute("select B.ISBN, B.title, q1.Author_name,  case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'  \
                        else 'No' end as Available \
                        from books as B \
                        join \
                        (SELECT ISBN, STRING_AGG(a.name::TEXT, ',') AS Author_name \
                        FROM BOOK_AUTHORS as ba \
                        NATURAL JOIN authors as a \
                        GROUP BY ISBN) as q1 \
                        on b.isbn = q1.isbn \
                        WHERE b.ISBN = '" + searchlist[i] + "';")
            result.append(cursor.fetchall())
            conn.commit()
            print(result)

            cursor = conn.cursor()
            cursor.execute("select B.ISBN, B.title, q1.Author_name,  case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'  \
                        else 'No' end as Available \
                        from books as B \
                        join \
                        (SELECT ISBN, STRING_AGG(a.name::TEXT, ',') AS Author_name \
                        FROM BOOK_AUTHORS as ba \
                        NATURAL JOIN authors as a \
                        GROUP BY ISBN) as q1 \
                        on b.isbn = q1.isbn \
                        WHERE b.title ILIKE '" + book_string + "%';")
            '''
            cursor.execute("select b.isbn, b.title, a.name, case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'" +
                           "else 'No' end as Available " +
                           "from books as b natural join  book_authors as ba natural join authors a where b.title ILIKE '" + book_string + "%';")
            
            '''
            result.append(cursor.fetchall())
            conn.commit()
            print(result)

            cursor = conn.cursor()
            cursor.execute("select B.ISBN, B.title, q1.Author_name,  case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'  \
                        else 'No' end as Available \
                        from books as B \
                        join \
                        (SELECT ISBN, STRING_AGG(a.name::TEXT, ',') AS Author_name \
                        FROM BOOK_AUTHORS as ba \
                        NATURAL JOIN authors as a \
                        GROUP BY ISBN) as q1 \
                        on b.isbn = q1.isbn \
                        WHERE Author_name ILIKE '%" + searchlist[i] + "%';")
            '''
            cursor.execute("select b.isbn, b.title, a.name, case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'" +
                           "else 'No' end as Available " +
                           "from books as b natural join  book_authors as ba natural join authors a where a.name ILIKE '" + searchlist[i] + "%';")
            result.append(cursor.fetchall())
            '''
            result.append(cursor.fetchall())
            conn.commit()
            print(result)

        conn.close()
        for subres in result:
            for array in subres:
                print(array)
                try:
                    my_tree.insert(parent='', index='end', iid=array,
                                   text="", values=(array), tag="orow")
                except:
                    continue

    def searchbutton(self, searchEntry, my_tree, controller):
        searchBtn = Button(self, text="Search", padx=65, pady=2,
                           width=5, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: self.search(searchEntry, my_tree))

        searchBtn.grid(row=3, column=5, columnspan=1, rowspan=1)

    def initializetree(self, controller):
        searchLabel = Label(self, text="Search", font=('Arial', 15))
        searchLabel.grid(row=3, column=0, columnspan=1, padx=10, pady=0)
        my_tree = ttk.Treeview(self)
        style = ttk.Style()
        style.configure("Treeview.Heading", font=(
            'Arial Bold', 15))

        my_tree['columns'] = ("ISBN", "Book Name", "Author", "Available")

        my_tree.column("#0", width=0, stretch=NO)
        my_tree.column("ISBN", anchor=W, width=170)
        my_tree.column("Book Name", anchor=W, width=150)
        my_tree.column("Author", anchor=W, width=150)
        my_tree.column("Available", anchor=W, width=165)

        my_tree.heading("ISBN", text="ISBN", anchor=CENTER)
        my_tree.heading("Book Name", text="Book Name",
                        anchor=CENTER)
        my_tree.heading("Author", text="Author", anchor=CENTER)
        my_tree.heading("Available", text="Available",
                        anchor=CENTER)
        return my_tree

    def select(self, my_tree, isbn_arr):
        selected_item = my_tree.selection()[0]
        sisbn = str(my_tree.item(selected_item)['values'][0])
        available = str(my_tree.item(selected_item)['values'][3])
        if (available == 'No'):
            messagebox.showinfo("Error", "Selected book is unavailable")
            return
        if (sisbn in isbn_arr):
            messagebox.showinfo("Error", "Book already selected.")
            return
        isbn_arr.append(sisbn)
        print("available " + available)
        # print(isbn_arr)

    def selectbutton(self, my_tree, isbn_arr):
        selectBtn = Button(self, text="Select Book", padx=70, pady=2,
                           width=4, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: self.select(my_tree, isbn_arr))

        selectBtn.grid(row=19, column=4, columnspan=1, rowspan=1)

    def checkoututil(self, isbn_arr):
        print(isbn_arr)

    def checkoutbutton(self, controller, isbn_arr, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        checkOutBtn = Button(self, text="Check Out", padx=65, pady=2,
                             width=4, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: controller.show_page1(isbn_arr))

        checkOutBtn.grid(row=19, column=5, columnspan=2, rowspan=1)

    def checkinbutton(self, controller, my_tree):
        checkInBtn = Button(self, text="Check In", padx=65, pady=7,
                            width=5, bd=5, font=('Arial', 15), bg="#F4FE82", command=lambda: controller.show_page2())

        checkInBtn.grid(row=100, column=1, columnspan=2, rowspan=2, pady=20)

    def addborrowerbutton(self, controller, my_tree):
        checkOutBtn = Button(self, text="Add Borrower", padx=65, pady=7,
                             width=5, bd=5, font=('Arial', 15), bg="#FF9999", command=lambda: controller.show_page4())

        checkOutBtn.grid(row=100, column=3, columnspan=2, rowspan=1, pady=20)

    def updatefines(self):
        conn = connection()
        cursor = conn.cursor()
        cursor.execute("update fines \
                set fine_amount = case when current_date > due_date\
                then (current_date - due_date)*.25\
                else 0 \
                end \
                from book_loans \
                where fines.loan_id = book_loans.loan_id;")
        conn.commit()
        messagebox.showinfo("Success", "Fines updated successfully ")

    def updatefinesbutton(self, controller, my_tree):
        checkOutBtn = Button(self, text="Update Fines", padx=65, pady=7,
                             width=5, bd=5, font=('Arial', 15), bg="#84E8F8", command=lambda: self.updatefines())

        checkOutBtn.grid(row=100, column=5, columnspan=2, rowspan=1, pady=20)

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = Label(
            self, text="Library Management System", font=('Arial Bold', 30))
        label.grid(row=0, column=1, columnspan=8, rowspan=2, padx=15, pady=40)
        searchEntry = self.showsearchbar()
        my_tree = self.initializetree(controller)
        isbn_arr = []
        self.refreshTable(my_tree)
        self.searchbutton(searchEntry, my_tree, controller)
        self.selectbutton(my_tree, isbn_arr)
        self.checkoutbutton(controller, isbn_arr, my_tree)
        self.checkinbutton(controller, my_tree)
        self.addborrowerbutton(controller, my_tree)
        self.updatefinesbutton(controller, my_tree)
