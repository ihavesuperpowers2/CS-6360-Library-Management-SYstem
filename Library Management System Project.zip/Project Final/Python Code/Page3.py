import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class Page3(tk.Frame):
    def refreshTable(self, my_tree, b_cardid, loan_ids):
        for data in my_tree.get_children():
            my_tree.delete(data)
        print("i am here....")
        loan_id = []
        conn = connection()
        cursor = conn.cursor()
        cursor.execute("select f.loan_id, bl.isbn, bl.due_date, f.fine_amount \
        from fines as f natural join book_loans as bl where bl.card_id = '" + b_cardid[0] + "'and  bl.date_in > bl.due_date and f.paid != 'TRUE';")
        result = cursor.fetchall()
        total_amount = 0
        conn.commit()
        conn.close()
        for array in result:
            total_amount = total_amount + array[3]
            loan_ids.append(array[0])
            my_tree.insert(parent='', index='end', iid=array,
                           text="", values=(array), tag="orow")
        '''
        for array in read():
            my_tree.insert(parent='', index='end', iid=array,
                           text="", values=(array), tag="orow")
        '''

        my_tree.tag_configure(
            'orow', background='#EEEEEE', font=('Arial', 12))
        my_tree.grid(row=8, column=1, columnspan=6,
                     rowspan=11, padx=0, pady=20)
        return total_amount

    def initializetree(self, controller, b_cardid):

        my_tree = ttk.Treeview(self)
        style = ttk.Style()
        style.configure("Treeview.Heading", font=(
            'Arial Bold', 15))

        my_tree['columns'] = ("Loan ID", "ISBN", "Due Date", "Amount")

        my_tree.column("#0", width=0, stretch=NO)
        my_tree.column("Loan ID", anchor=W, width=170)
        my_tree.column("ISBN", anchor=W, width=150)
        my_tree.column("Due Date", anchor=W, width=150)
        my_tree.column("Amount", anchor=W, width=165)

        my_tree.heading("Loan ID", text="Loan ID", anchor=CENTER)
        my_tree.heading("ISBN", text="ISBN",
                        anchor=CENTER)
        my_tree.heading("Due Date", text="Due Date", anchor=CENTER)
        my_tree.heading("Amount", text="Amount",
                        anchor=CENTER)

        return my_tree

    def payment(self, loan_ids, controller):
        conn = connection()
        cursor = conn.cursor()
        for i in loan_ids:
            cursor.execute("update fines \
                set paid = TRUE \
                where loan_id = '" + i + "';")

        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Loans successfully paid!")
        controller.show_startpage()

    def paymentbutton(self, loan_ids, total_amount, controller):
        amount_text = "Pay Amount: $" + str(total_amount)
        paymentBtn = Button(self, text=amount_text, padx=65, pady=7,
                            width=4, bd=5, font=('Arial', 15), bg="#F4FE82", command=lambda: self.payment(loan_ids, controller))

        paymentBtn.grid(row=19, column=2, columnspan=1, rowspan=1, padx=200)

    def __init__(self, parent, controller, b_cardid):
        self.b_cardid = b_cardid
        tk.Frame.__init__(self, parent)

        label = Label(
            self, text="Fine Payment", font=('Arial Bold', 30))
        label.grid(row=1, column=1, columnspan=8, rowspan=2, padx=15, pady=40)

        my_tree = self.initializetree(controller, b_cardid)
        loan_ids = []
        total_amount = self.refreshTable(my_tree, b_cardid, loan_ids)
        print(loan_ids, total_amount)
        self.paymentbutton(loan_ids, total_amount, controller)

        # self.searchbutton(searchEntry, my_tree, controller)
        # self.selectbutton(my_tree, b_cardid)
        # self.checkinbutton(controller, my_tree, b_cardid)
