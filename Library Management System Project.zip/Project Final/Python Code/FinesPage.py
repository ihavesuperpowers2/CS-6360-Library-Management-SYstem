import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk
from Page3 import Page3


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class FinesPage(tk.Frame):
    pass
