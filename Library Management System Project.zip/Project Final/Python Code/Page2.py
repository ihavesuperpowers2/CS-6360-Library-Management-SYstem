import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class Page2(tk.Frame):
    def refreshTable(self, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        '''
        for array in read():
            my_tree.insert(parent='', index='end', iid=array,
                           text="", values=(array), tag="orow")
        '''

        my_tree.tag_configure(
            'orow', background='#EEEEEE', font=('Arial', 12))
        my_tree.grid(row=8, column=1, columnspan=6,
                     rowspan=11, padx=0, pady=20)

    def showsearchbar(self):
        searchLabel = Label(self, text="Search", font=('Arial', 15))
        searchLabel.grid(row=3, column=0, columnspan=1, padx=10, pady=0)
        searchEntry = Entry(self, width=40, bd=5,
                            font=('Arial', 15))

        searchEntry.grid(row=3, column=1, columnspan=4, padx=5, pady=2)
        return searchEntry

        # checkOutBtn = Button(self, text="Check Out", padx=65, pady=7,
        # width=5, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: self.show_page1(searchEntry))

        # checkOutBtn.grid(row=31, column=1, columnspan=2, rowspan=1)
    def search(self, searchEntry, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        searchstring = str(searchEntry.get())
        searchlist = searchstring.split(' ')
        conn = connection()
        cursor = conn.cursor()
        result = []
        for i in searchlist:
            cursor.execute("select bl.loan_id, b.isbn, b.title, bl.card_id, bo.bname \
            from books as b natural join book_loans as bl natural join borrowers as bo where bl.card_id = '" +
                           i + "' and bl.date_in is NULL ")
            result.append(cursor.fetchall())
            conn.commit()
            cursor.execute("select bl.loan_id, b.isbn, b.title, bl.card_id, bo.bname \
            from books as b natural join book_loans as bl natural join borrowers as bo where bl.isbn = '" +
                           i + "' and bl.date_in is NULL")
            result.append(cursor.fetchall())
            conn.commit()
            cursor.execute("select bl.loan_id, b.isbn, b.title, bl.card_id, bo.bname \
            from books as b natural join book_loans as bl natural join borrowers as bo where bo.bname  ilike'" +
                           i + "%'and bl.date_in is NULL;")
            result.append(cursor.fetchall())

            conn.commit()
        conn.close()
        print(result)
        if (len(result[0]) == 0 and len(result[1]) == 0 and len(result[2]) == 0):
            messagebox.showinfo(
                "Error", "Searched item not found in checked in list.")

        for subres in result:
            for array in subres:
                my_tree.insert(parent='', index='end', iid=array,
                               text="", values=(array), tag="orow")

    def searchbutton(self, searchEntry, my_tree, controller):
        searchBtn = Button(self, text="Search", padx=65, pady=2,
                           width=5, bd=5, font=('Arial', 15), bg="#84F894", command=lambda: self.search(searchEntry, my_tree))

        searchBtn.grid(row=3, column=5, columnspan=1, rowspan=1)

    def initializetree(self, controller):
        searchLabel = Label(self, text="Search", font=('Arial', 15))
        searchLabel.grid(row=3, column=0, columnspan=1, padx=10, pady=0)
        my_tree = ttk.Treeview(self)
        style = ttk.Style()
        style.configure("Treeview.Heading", font=(
            'Arial Bold', 15))

        my_tree['columns'] = ("Loan ID", "ISBN", "Book Name",
                              "Card ID", "Borrower Name")

        my_tree.column("#0", width=0, stretch=NO)
        my_tree.column("Loan ID", anchor=W, width=127)
        my_tree.column("ISBN", anchor=W, width=127)
        my_tree.column("Book Name", anchor=W, width=127)
        my_tree.column("Card ID", anchor=W, width=127)
        my_tree.column("Borrower Name", anchor=W, width=127)

        my_tree.heading("Loan ID", text="Loan ID", anchor=CENTER)
        my_tree.heading("ISBN", text="ISBN", anchor=CENTER)
        my_tree.heading("Book Name", text="Book Name",
                        anchor=CENTER)
        my_tree.heading("Card ID", text="Card ID", anchor=CENTER)
        my_tree.heading("Borrower Name", text="Borrower",
                        anchor=CENTER)
        return my_tree

    def select(self, my_tree, loan_arr, b_cardid):
        selected_item = my_tree.selection()[0]

        b_cardid.append(str(my_tree.item(selected_item)['values'][3]))
        loan_id = str(my_tree.item(selected_item)['values'][0])
        loan_arr.append(loan_id)
        print("hello")
        # print(isbn_arr)

    def selectbutton(self, my_tree, loan_arr, b_cardid):
        selectBtn = Button(self, text="Select", padx=65, pady=7,
                           width=4, bd=5, font=('Arial', 15), bg="#FF9999", command=lambda: self.select(my_tree, loan_arr, b_cardid))

        selectBtn.grid(row=19, column=1, columnspan=1, rowspan=1)

    def checkin(self, controller, my_tree, loan_arr, b_cardid):
        print("card id", b_cardid)
        conn = connection()
        cursor = conn.cursor()
        for i in loan_arr:
            cursor.execute(
                "update book_loans as b set date_in = CURRENT_DATE where b.loan_id = '" + i + "';")

        cursor.execute("update fines \
            set paid = 'true' \
            from book_loans as bl \
            where  fines.loan_id = bl.loan_id and bl.date_in is not NULL and bl.date_in <= bl.due_date;")

        conn.commit()
        cursor.close()
        conn = connection()
        cursor = conn.cursor()
        cursor.execute("select count(*) \
        from fines as f natural join book_loans as bl where bl.card_id = '" + b_cardid[0] + "'and  bl.date_in > bl.due_date and f.paid != 'TRUE';")
        result = cursor.fetchall()
        if (result[0][0] == 0):
            cursor.execute("update fines \
                set paid = TRUE \
                where loan_id = '" + i + "';")
            messagebox.showinfo(
                "Success", "Book(s) successfully checkedin.")
            controller.show_startpage()
            return

        controller.show_page3(b_cardid)

    def checkinbutton(self, controller, my_tree, loan_arr, b_cardid):

        checkinBtn = Button(self, text="Check In", padx=65, pady=7,
                            width=4, bd=5, font=('Arial', 15), bg="#F4FE82", command=lambda: self.checkin(controller, my_tree, loan_arr, b_cardid))

        checkinBtn.grid(row=19, column=3, columnspan=1, rowspan=1)

    def backbutton(self, controller):

        backBtn = Button(self, text="Go Back", padx=65, pady=7,
                         width=4, bd=5, font=('Arial', 15), bg="#84E8F8", command=lambda: controller.show_startpage())

        backBtn.grid(row=19, column=5, columnspan=1, rowspan=1)

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = Label(
            self, text="Check In", font=('Arial Bold', 30))
        label.grid(row=0, column=0, columnspan=8, rowspan=2, padx=15, pady=40)
        searchEntry = self.showsearchbar()
        my_tree = self.initializetree(controller)
        loan_arr = []
        b_cardid = []
        self.refreshTable(my_tree)
        self.searchbutton(searchEntry, my_tree, controller)
        self.selectbutton(my_tree, loan_arr, b_cardid)
        self.checkinbutton(controller, my_tree, loan_arr, b_cardid)
        self.backbutton(controller)
