import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class Page4(tk.Frame):
    def add(self, SSNEntry, BorrowerEntry, AddressEntry, PhoneEntry):

        SSNString = str(SSNEntry.get())
        BorrowerString = str(BorrowerEntry.get())
        AddressString = str(AddressEntry.get())
        PhoneString = str(PhoneEntry.get())
        if (SSNString == '' or BorrowerString == '' or AddressString == '' or PhoneString == ''):
            messagebox.showinfo(
                "Error", "All fields are required to add borrower.")
            return

        conn = connection()
        cursor = conn.cursor()
        cursor.execute("select * from borrowers where ssn='" +
                       SSNString + "';")
        result = cursor.fetchall()
        conn.commit()
        if (len(result) != 0):
            messagebox.showinfo(
                "Error", "User already exists.")
            return

        conn = connection()
        cursor = conn.cursor()
        cursor.execute("select count(*) from borrowers;")
        result = cursor.fetchall()
        conn.commit()

        print(result[0][0])
        next_id = 'ID'
        curr_id = result[0][0] + 1
        curr_len_id = len(str(curr_id))
        for i in range(6 - curr_len_id):
            next_id = next_id + '0'
        next_id = next_id + str(curr_id)
        print(next_id)

        conn = connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO BORROWERS VALUES ('" + next_id + "','" + SSNString + "','" + BorrowerString +
                       "','" + AddressString + "','" + PhoneString +
                       "');")
        conn.commit()
        messagebox.showinfo(
            "Success", "Borrower added successfully with Card ID " + next_id)

        print(SSNEntry, BorrowerEntry, AddressEntry, PhoneEntry)

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = Label(
            self, text="Add Borrower", font=('Arial Bold', 30))
        label.grid(row=0, column=2, columnspan=8, rowspan=2, padx=0, pady=40)

        SSNLabel = Label(self, text="SSN", font=('Arial', 15), anchor='e')
        SSNLabel.grid(row=3, column=1, columnspan=1, padx=4, pady=10)
        SSNEntry = Entry(self, width=40, bd=5,
                         font=('Arial', 15))
        SSNEntry.grid(row=3, column=2, columnspan=4, padx=2, pady=10)
        BorrowerLabel = Label(self, text="Name",
                              font=('Arial', 15), anchor='e')
        BorrowerLabel.grid(row=5, column=1, columnspan=1, padx=2, pady=10)
        BorrowerEntry = Entry(self, width=40, bd=5,
                              font=('Arial', 15))
        BorrowerEntry.grid(row=5, column=2, columnspan=4, padx=4, pady=10)
        AddressLabel = Label(self, text="Address",
                             font=('Arial', 15), anchor='e')
        AddressLabel.grid(row=7, column=1, columnspan=1, padx=2, pady=10)
        AddressEntry = Entry(self, width=40, bd=5,
                             font=('Arial', 15))
        AddressEntry.grid(row=7, column=2, columnspan=4, padx=4, pady=10)
        PhoneLabel = Label(self, text="Phone No",
                           font=('Arial', 15), anchor='e')
        PhoneLabel.grid(row=9, column=1, columnspan=1, padx=2, pady=10)
        PhoneEntry = Entry(self, width=40, bd=5,
                           font=('Arial', 15))
        PhoneEntry.grid(row=9, column=2, columnspan=4, padx=4, pady=10)

        selectBtn = Button(self, text="Add", padx=65, pady=7,
                           width=4, bd=5, font=('Arial', 15), bg="#FF9999", command=lambda: self.add(SSNEntry, BorrowerEntry, AddressEntry, PhoneEntry))

        selectBtn.grid(row=13, column=2, columnspan=1,
                       rowspan=1, padx=30, pady=30)

        backBtn = Button(self, text="Go Back", padx=65, pady=7,
                         width=4, bd=5, font=('Arial', 15), bg="#84E8F8", command=lambda: controller.show_startpage())

        backBtn.grid(row=13, column=4, columnspan=1,
                     rowspan=1, padx=30, pady=30)
