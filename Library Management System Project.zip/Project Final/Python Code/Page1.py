import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk
import Page2
import Page1


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class Page1(tk.Frame):
    def refreshTable(self, my_tree):
        for data in my_tree.get_children():
            my_tree.delete(data)
        '''
        for array in read():
            my_tree.insert(parent='', index='end', iid=array,
                           text="", values=(array), tag="orow")
        '''

        my_tree.tag_configure(
            'orow', background='#EEEEEE', font=('Arial', 12))
        my_tree.grid(row=8, column=1, columnspan=6,
                     rowspan=11, padx=0, pady=20)

    def initializetree(self, controller):
        tree_2 = ttk.Treeview(self)
        style = ttk.Style()
        style.configure("Treeview.Heading", font=(
            'Arial Bold', 15))

        tree_2['columns'] = ("ISBN", "Book Name", "Author", "Available")

        tree_2.column("#0", width=0, stretch=NO)
        tree_2.column("ISBN", anchor=W, width=150)
        tree_2.column("Book Name", anchor=W, width=180)
        tree_2.column("Author", anchor=W, width=180)
        tree_2.column("Available", anchor=W, width=100)

        tree_2.heading("ISBN", text="ISBN", anchor=CENTER)
        tree_2.heading("Book Name", text="Book Name",
                       anchor=CENTER)
        tree_2.heading("Author", text="Author", anchor=CENTER)
        tree_2.heading("Available", text="Available",
                       anchor=CENTER)
        return tree_2

    def showcheckoutitems(self, tree_2, isbn_arr):
        for data in tree_2.get_children():
            tree_2.delete(data)

        conn = connection()
        cursor = conn.cursor()
        for isbn in isbn_arr:
            cursor.execute("select B.ISBN, B.title, q1.Author_name,  case when b.isbn not in (select isbn from book_loans as bl where bl.isbn = b.isbn and bl.date_in is NULL) then 'Yes'  \
                        else 'No' end as Available \
                        from books as B \
                        join \
                        (SELECT ISBN, STRING_AGG(a.name::TEXT, ',') AS Author_name \
                        FROM BOOK_AUTHORS as ba \
                        NATURAL JOIN authors as a \
                        GROUP BY ISBN) as q1 \
                        on b.isbn = q1.isbn \
                        WHERE b.ISBN = '" + isbn + "';")
            result = cursor.fetchall()

            for array in result:
                print(array)
                tree_2.insert(parent='', index='end', iid=array,
                              text="", values=(array), tag="orow")
        conn.commit()
        conn.close()

    def borrowerentryutil(self):
        Borrowerlabel = Label(self, text="Enter Card Id", font=('Arial', 15))
        Borrowerlabel.grid(row=25, column=1, columnspan=1, padx=2, pady=5)
        BorrowerEntry = Entry(self, width=43, bd=5, text="Enter Card Id",
                              font=('Arial', 15))
        BorrowerEntry.grid(row=25, column=2, columnspan=4, padx=5, pady=2)
        return BorrowerEntry

    def checkoutbooks(self, isbn_arr, BorrowerEntry):
        curr_checkout_len = len(isbn_arr)
        borrower_card_id = str(BorrowerEntry.get())
        conn = connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM BOOK_LOANS WHERE Card_id='" +
                       borrower_card_id + "' AND DATE_IN IS NULL ")
        result = cursor.fetchall()
        total_books_borrowed = curr_checkout_len + result[0][0]
        cursor.execute("select count(*) \
        from fines as f natural join book_loans as bl where bl.card_id = '" + borrower_card_id + "'and  current_date > bl.due_date and f.paid != 'TRUE';")
        result = cursor.fetchall()
        if (result[0][0] > 0):
            messagebox.showinfo(
                "Error", "Borrower already has book(s) checked in post due date.")
            return

        if (total_books_borrowed > 3):
            messagebox.showinfo(
                "Error", "Borrower already has more than 3 books")
            return
        else:
            cursor.execute("SELECT COUNT(*) FROM BOOK_LOANS")
            result = cursor.fetchall()
            total_loans = result[0][0]
            for i in isbn_arr:
                cursor.execute("SELECT COUNT(*) FROM BOOK_LOANS WHERE ISBN='" +
                               i + "' ")

                result = cursor.fetchall()
                if (result[0][0] > 0):
                    messagebox.showinfo("Error", "Book already checked out.")
                    return

            for i in isbn_arr:
                cursor.execute("INSERT INTO BOOK_LOANS VALUES ('" + str(total_loans + 1) +
                               "','" + i + "','" + borrower_card_id+"', CURRENT_DATE, CURRENT_DATE+14, NULL)")

                conn.commit()
                cursor.execute("INSERT INTO FINES VALUES ('" + str(total_loans + 1) +
                               "', 0, 'false');")

                conn.commit()
                total_loans = total_loans + 1

            messagebox.showinfo("Success", "Checkout Successful")

        conn.close()

        '''
        for isbn in isbn_arr:
            cursor.execute("SELECT * FROM BOOKS WHERE ISBN='" +
                           isbn + "' ")
            result = cursor.fetchall()

            for array in result:
                print(array)
                tree_2.insert(parent='', index='end', iid=array,
                              text="", values=(array), tag="orow")
        conn.commit()
        conn.close()
        '''

    def __init__(self, parent, controller, isbn_arr):
        tk.Frame.__init__(self, parent)
        label = Label(
            self, text="Check Out", font=('Arial Bold', 30))
        label.grid(row=0, column=1, columnspan=8, rowspan=2, padx=15, pady=40)
        tree_2 = self.initializetree(controller)

        self.refreshTable(tree_2)
        self.showcheckoutitems(tree_2, isbn_arr)

        Gobackbtn = Button(self, text="Go back", padx=65, pady=7,
                           width=5, bd=5, font=('Arial', 15), bg="#FF9999", command=lambda: controller.show_startpage())

        Gobackbtn.grid(row=31, column=4, columnspan=2,
                       rowspan=1, pady=7, padx=10)
        BorrowerEntry = self.borrowerentryutil()
        Checkoutbtn = Button(self, text="Check Out", padx=65, pady=7,
                             width=5, bd=5, font=('Arial', 15), bg="#84E8F8", command=lambda: self.checkoutbooks(isbn_arr, BorrowerEntry))

        Checkoutbtn.grid(row=31, column=2, columnspan=2,
                         rowspan=1, pady=7, padx=10)
