import psycopg2
from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import tkinter as tk
from Page2 import Page2
from Page1 import Page1
from Page3 import Page3
from Page4 import Page4
from StartPage import StartPage


def connection():
    conn = psycopg2.connect(database="LibraryManagementSystem",
                            user="postgres",
                            host="localhost",
                            password="bluepelican15",
                            port=5432)
    return conn


class tkinterApp(tk.Frame):
    def show_startpage(self):
        frame = StartPage(self.container, self)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

    def show_page1(self, isbn_arr):
        print(isbn_arr)

        frame = Page1(self.container, self, isbn_arr)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

    def show_page2(self):
        frame = Page2(self.container, self)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

    def show_page3(self, b_cardid):
        frame = Page3(self.container, self, b_cardid)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

    def show_page4(self):
        frame = Page4(self.container, self)
        frame.grid(row=0, column=0, sticky="nsew")
        frame.tkraise()

    def __init__(self, parent=None):
        tk.Frame.__init__(self, parent)
        tk.Frame.pack(self)
        container = tk.Frame(self)
        self.container = container
        container.pack(side="top", fill="both", expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.show_startpage()
        # frame.showsearchbar(self)


app = tk.Tk()
app.wm_title("Library Management System")
tkinterApp(app)
app.mainloop()
