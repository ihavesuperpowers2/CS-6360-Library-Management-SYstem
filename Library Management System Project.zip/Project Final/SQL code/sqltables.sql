DROP TABLE IF EXISTS BOOKS;
CREATE TABLE BOOKS(
  Isbn    VARCHAR(200) NOT NULL,
  Title   VARCHAR(400)
  --CONSTRAINT pk_isbn PRIMARY KEY(Isbn)
);

--INSERT INTO Books(Isbn, Title) SELECT $$9780195153446$$,$$Classical Mythology$$ WHERE NOT EXISTS ( SELECT isbn FROM books WHERE isbn =$$9780195153446$$);

DROP TABLE IF EXISTS BOOK_AUTHORS;
CREATE TABLE BOOK_AUTHORS (
  Author_id VARCHAR(200) NOT NULL,
  Isbn VARCHAR(400) NOT NULL
  --CONSTRAINT pk_bookauthors PRIMARY KEY(Author_id, Isbn),
  --CONSTRAINT fk_bookauthors FOREIGN KEY (Isbn) REFERENCES BOOKS(Isbn)
);

INSERT INTO BOOK_AUTHORS(Author_id, Isbn) SELECT $$abc$$,$$def$$ WHERE NOT EXISTS ( SELECT Author_id FROM Book_Authors WHERE Author_id =$$abc$$);

DROP TABLE IF EXISTS AUTHORS;
CREATE TABLE AUTHORS (
  Author_id  VARCHAR(200)  NOT NULL UNIQUE,
  Name VARCHAR(400)
  --CONSTRAINT pk_authors PRIMARY KEY(Author_id),
  --CONSTRAINT fk_authors FOREIGN KEY (Author_id) REFERENCES BOOK_AUTHORS(Author_id)
);


CREATE TABLE IF NOT EXISTS public.book_loans
(
    loan_id character varying(200) COLLATE pg_catalog."default" NOT NULL,
    isbn character varying(200) COLLATE pg_catalog."default",
    card_id character varying(200) COLLATE pg_catalog."default",
    date_out date,
    due_date date,
    date_in date,
    CONSTRAINT pk_book_loans PRIMARY KEY (loan_id),
    CONSTRAINT fk_book_loans_card_id FOREIGN KEY (card_id)
        REFERENCES public.borrowers (card_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk_book_loans_isbn FOREIGN KEY (isbn)
        REFERENCES public.books (isbn) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE IF NOT EXISTS public.borrowers
(
    card_id character varying(200) COLLATE pg_catalog."default" NOT NULL,
    ssn character varying(200) COLLATE pg_catalog."default",
    bname character varying(200) COLLATE pg_catalog."default",
    address character varying(200) COLLATE pg_catalog."default",
    phone character varying(100) COLLATE pg_catalog."default",
    CONSTRAINT pk_borrowers PRIMARY KEY (card_id)
);

CREATE TABLE IF NOT EXISTS public.fines
(
    loan_id character varying(200) COLLATE pg_catalog."default" NOT NULL,
    fine_amount numeric(5,2),
    paid boolean,
    CONSTRAINT pk_fines PRIMARY KEY (loan_id),
    CONSTRAINT fk_fines FOREIGN KEY (loan_id)
        REFERENCES public.book_loans (loan_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);
