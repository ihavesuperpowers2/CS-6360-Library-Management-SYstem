Dependencies:

Python 3.9
Postgres 16.0
Pyscopg library

Ensure all dependencies are installed in the system.
Create SQL tables in sqltables.sql
Run all insert commands in parse folder in pgadmin.
Connect python to postgressql.
Insert entries from parse_result folder.
Run python file main_2.py. Home page should appear noe
